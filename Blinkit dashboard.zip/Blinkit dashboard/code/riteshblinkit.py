import pandas as pd

import matplotlib.pyplot as plt


import subprocess

powerbipath = "C:\\Program Files (x86)\\Microsoft Power BI Desktop\\bin\\PBIDesktop.exe"
filepath = "C:\\Users\\Ritesh\\Docoment\\Blinkit dashboard\\ritesh blinkit.pbix"

subprocess.Popen([powerbipath , filepath])

# Read BlinkIT Grocery Data.csv
print("----------------------------------Read first csv file---------------------------------------------------------")
# Read the CSV file
data = pd.read_csv("C:\\Users\\Ritesh\\Documents\\Blinkit dashboard\\BlinkIT Grocery Data.csv")
print(data)
print("----------------------------close first csv file ---------------------------------------------------------------")

# Display the first few rows of the dataset
print("Dataset preview:")
print(data.head())

# Basic statistics: Grouping by a relevant column (e.g., Category) and summarizing
group_column = 'Item Type'  # Replace with the actual column name in your data
value_column = 'Sales'  # Replace with the relevant numeric column name

if group_column in data.columns and value_column in data.columns:
    grouped_data = data.groupby(group_column)[value_column].agg(['sum', 'mean', 'min', 'max']).reset_index()
    print("\nGrouped Statistics:")
    print(grouped_data)

    # Plot: Bar chart for total sales by category
    plt.figure(figsize=(10, 6))
    plt.bar(grouped_data[group_column], grouped_data['sum'], color='skyblue')
    plt.title('Total Sales by Item Type')
    plt.xlabel(group_column)
    plt.ylabel('Total Sales')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

    # Plot: Line chart for mean sales by category
    plt.figure(figsize=(10, 6))
    plt.plot(grouped_data[group_column], grouped_data['mean'], marker='o', color='orange', label='Mean Sales')
    plt.title('Mean Sales by Item Type')
    plt.xlabel(group_column)
    plt.ylabel('Mean Sales')
    plt.xticks(rotation=45)
    plt.legend()
    plt.tight_layout()
    plt.show()
else:
    print(f"Columns '{group_column}' and/or '{value_column}' not found in the dataset.")