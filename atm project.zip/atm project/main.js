let balance = 0;
let transactionHistory = [];

const validUsername = "user123";
const validPassword = "pass123";

function login() {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const loginError = document.getElementById("loginError");

  if (username === validUsername && password === validPassword) {
    document.getElementById("start").style.display = "none";
    document.getElementById("menu").style.display = "block";
    document.getElementById("currentUser").textContent = username;
    updateDisplay();
    loginError.textContent = "";
  } else {
    loginError.textContent = "Invalid username or password.";
  }
}

function logout() {
  document.getElementById("menu").style.display = "none";
  document.getElementById("start").style.display = "block";
  document.getElementById("username").value = "";
  document.getElementById("password").value = "";
}

function showSection(id) {
  document.querySelectorAll(".section").forEach(sec => sec.style.display = "none");
  document.getElementById(id).style.display = "block";
  if (id === "balanceSection") {
    document.getElementById("userBalance").textContent = `₹${balance.toFixed(2)}`;
  }
}

function hideSection(id) {
  document.getElementById(id).style.display = "none";
}

function updateDisplay() {
  document.getElementById("balanceDisplay").textContent = balance.toFixed(2);
  const historyList = document.getElementById("transactionHistory");
  historyList.innerHTML = "";
  transactionHistory.forEach(entry => {
    const li = document.createElement("li");
    li.textContent = entry;
    historyList.appendChild(li);
  });
}

function deposit() {
  const amount = parseFloat(document.getElementById("depositAmount").value);
  const error = document.getElementById("depositError");

  if (!isNaN(amount) && amount > 0) {
    balance += amount;
    transactionHistory.push(`Deposited ₹${amount.toFixed(2)}`);
    updateDisplay();
    error.textContent = "";
  } else {
    error.textContent = "Enter a valid amount.";
  }
  document.getElementById("depositAmount").value = "";
}

function withdraw() {
  const amount = parseFloat(document.getElementById("withdrawAmount").value);
  const error = document.getElementById("withdrawError");

  if (!isNaN(amount) && amount > 0) {
    if (balance >= amount) {
      balance -= amount;
      transactionHistory.push(`Withdrew ₹${amount.toFixed(2)}`);
      updateDisplay();
      error.textContent = "";
    } else {
      error.textContent = "Insufficient balance.";
    }
  } else {
    error.textContent = "Enter a valid amount.";
  }
  document.getElementById("withdrawAmount").value = "";
}
