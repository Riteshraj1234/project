import pandas as pd


import matplotlib.pyplot as plt


import subprocess


# Launch Power BI Desktop with the given PBIX file
powerbipath = "C:\\Program Files (x86)\\Microsoft Power BI Desktop\\bin\\PBIDesktop.exe"
filepath = "C:\\Users\\Ritesh\\Documents\\dashboard project\\RITESH RAJ ECOMMERCE SALES DASHBOARD\\RITESH RAJ dashboard.pbix"
subprocess.Popen([powerbipath, filepath])

# Read and display Details.csv
print("----------------------------------Read Details.csv---------------------------------------------------------")
data = pd.read_csv("C:\\Users\\Ritesh\\Documents\\dashboard project\\RITESH RAJ ECOMMERCE SALES DASHBOARD\\Details.csv")
print(data)
print("----------------------------Close Details.csv ---------------------------------------------------------------")

# Read and display Orders.csv
print("-----------------------------------Read Orders.csv--------------------------------------------------------")
df = pd.read_csv("C:\\Users\\Ritesh\\Documents\\dashboard project\\RITESH RAJ ECOMMERCE SALES DASHBOARD\\Orders.csv")
print(df)
print("-------------------------------------Close Orders.csv------------------------------------------------------")


# Read Details.csv
print("----------------------------------Read Details.csv---------------------------------------------------------")
details_file_path = "C:\\Users\\Ritesh\\Documents\\dashboard project\\RITESH RAJ ECOMMERCE SALES DASHBOARD\\Details.csv"
data = pd.read_csv(details_file_path)
print(data)

# Sorting the data by 'Amount' to get the top 10 sales
print("-----------------------------------Top 10 Sales by Amount------------------------------------------------")
top_10_sales = data.sort_values(by='Amount', ascending=False).head(10)
print(top_10_sales)

# Display the results in a more detailed way
print("\nTop 10 Sales in Detail:")
print(top_10_sales[['Order ID', 'Amount', 'Category', 'Sub-Category', 'PaymentMode']])

# Display the results using a bar chart
plt.figure(figsize=(10, 6))
plt.bar(top_10_sales['Order ID'], top_10_sales['Amount'], color='green')
plt.title('Top 10 Sales by Amount', fontsize=16)
plt.xlabel('Order ID', fontsize=14)
plt.ylabel('Amount', fontsize=14)
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

print("----------------------------------RITESH RAJ--------------------------------------------------------")
print("-----------------------------------ANKIT KUMAR--------------------------------------------------------")
print("-----------------------------------------RANJEET BHASKAR-------------------------------------------------")
print("-----------------------------------------NITISH MATHA-------------------------------------------------")
